	<script type="text/javascript" src="../includes/jQuery/jquery-3.2.1.js"></script>
	<script type="text/javascript" src="../includes/materialize/js/materialize.min.js"></script>  

	<!-- Angular JS -->
  
	<script type="text/javascript" src="../includes/angular/angular.min.js"></script>  
	<script type='text/javascript' src='../includes/js/angular-loading-bar/build/loading-bar.min.js'></script>

	<script type="text/javascript" src="../includes/materialize/js/angular-materialize.min.js"></script> 

   <script type="text/javascript" src="../includes/maskinput/jquery.maskedinput.js"></script>  
   <script type="text/javascript" src="../includes/maskinput/jquery-maskmoneyv3.1.1.js"></script>  
   <script type="text/javascript" src="../includes/js/notify_js/notify.min.js"></script>  
   <script type="text/javascript" src="../includes/jStarBox/jstarbox.js"></script>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-jcrop/0.9.12/css/jquery.Jcrop.min.css" />

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-jcrop/0.9.12/js/jquery.Jcrop.min.js"></script>
	<script type="text/javascript" src="../includes/ng-jcrop/ng-jcrop.js"></script>  

	<!-- PWA ===== nao retirar  -->
	<!-- PWA ===== nao retirar  -->
   <!-- <script type="text/javascript" src="../includes/js/app.js" async></script> -->
	<!-- PWA ===== nao retirar  -->
	<!-- PWA ===== nao retirar  -->

   <script type="text/javascript">
   	$(document).ready(function(){

   		$('.parallax').parallax();

		 	$('.button-collapse').sideNav({
		      menuWidth: 300, // Default is 300
		      edge: 'left', // Choose the horizontal origin
		      closeOnClick: true, // Closes side-nav on <a> clicks, useful for Angular/Meteor
		      draggable: true, // Choose whether you can drag to open on touch screens,
		      onOpen: function(el) { /* Do Stuff*/ }, // A function to be called when sideNav is opened
		      onClose: function(el) { /* Do Stuff*/ }, // A function to be called when sideNav is closed
		    });

   	});

   </script>