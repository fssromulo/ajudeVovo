# ajudeVovo

Este projeto tem como objetivo criar um site/app utilizando PHP para disponibilizar serviços e conectar voluntários a ajudar idosos, familiares, amigos e os próprios idosos a encontrarem essas pessoas dispostas a ajudar.
