<header>
   <div class="navbar-fixed">
      <nav>
       <div class="nav-wrapper blue #1889ff">
         <a href="#!" class="brand-logo"><img src="../includes/imagens/pwa_icons/android-chrome-48x48.png"/></a>
         <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
         <ul class="right hide-on-med-and-down">
            <li>
                <a href="#perfil_implementar">Perfil</a>
            </li>
            <li>
               <a href="../ConsultaServicoCliente/">Serviços</a>
            </li>
            <li>
               <a href="../ControleSolicitante/">Serviços solicitados</a>
            </li>
         </ul>
       </div>
      </nav>
   </div>
   <ul id="mobile-demo" class="side-nav">
     <li>
       <div class="user-view">
       <div class="background blue #1889ff">
         <div class="blue lighten-1"></div>
       </div>
       <a href="#!user"><img class="circle" src="../includes/imagens/pwa_icons/android-chrome-192x192.png"></a>
       <a href="#!name"><span class="white-text name">Adalberto Azevedo</span></a>
       <a href="#!email"><span class="white-text email">ajudevovo@gmail.com</span></a>
       </div>
     </li>
     <li><a href="#perfil_implementar"><i class="material-icons">face</i>Perfil</a></li>
     <li><a href="../ConsultaServicoCliente/"><i class="material-icons">room_service</i>Serviços</a></li>
     <li><a href="../ControleSolicitante/"><i class="material-icons">history</i>Serviços solicitados</a></li>
   </ul>

</header>
<div class="row"><div class="col-sm-12">&nbsp;</div></div>